/*import androidx.room.TypeConverter;
import edu.qc.seclass.glm.ReminderType;

import androidx.room.TypeConverter;

/package edu.qc.seclass.glm;

public class Converters {
    @TypeConverter
    public static ReminderType fromString (String type) {
        return type == null ? null : new ReminderType(type);
    }
    @TypeConverter
    public static String typeToString (ReminderType type) {
        return date == null ? null : date.getTime();
    }
}*/