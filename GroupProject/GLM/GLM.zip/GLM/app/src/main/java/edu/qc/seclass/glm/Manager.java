package edu.qc.seclass.glm;

public class Manager {


}
